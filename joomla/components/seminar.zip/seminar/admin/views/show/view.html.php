<?php
// no direct access
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.view');

/**
 * HTML View class for the News Component
 * @package ACLS.Site
 * @subpackage Calendar
 */
class SeminarViewShow extends JView {
    function display($tpl = null) {
        parent::display($tpl);
    }
}
