DROP TABLE IF EXISTS `#__acls_seminar`;
