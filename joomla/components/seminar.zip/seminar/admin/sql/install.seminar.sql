CREATE TABLE IF NOT EXISTS `#__acls_seminar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `started` datetime NULL,
  `content` text NOT NULL,
  `status` int(11) NOT NULL COMMENT '0: template 1: temp content 2: published',
  `mailto` text NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
