<?php
/**
 * @subpackage Seminar
 * @touch date 12/09/2012 9:00:00 AM
 * @link http://www.echoname.com
 * @version 1.0.0
 * @license GNU/GPL
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.application.component.controller');

/**
 * Show Controller
 * @subpackage Seminar
 */
class SeminarControllerShow extends JController { 

    function display() {
       parent::display();
    }

}
